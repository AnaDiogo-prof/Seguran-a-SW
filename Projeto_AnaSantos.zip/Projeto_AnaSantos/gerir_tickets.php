<?php

session_start();

require_once "ligabd.php";

// apenas admins
if (!isset($_SESSION['utilizador_tipo']) ||
    $_SESSION['utilizador_tipo'] !== 'admin') {

    header("Location: index.html");
    exit;
}

// -----------------------------
// VALIDAR TICKET
// -----------------------------
if (isset($_GET['validar'])) {

    $id = $_GET['validar'];

    // procurar ticket
    $st = $pdo->prepare("
        SELECT *
        FROM tickets
        WHERE id = ?
    ");
    $st->execute([$id]);

    $t = $st->fetch(PDO::FETCH_ASSOC);

    if ($t) {

        // inserir na tabela avarias
        $ins = $pdo->prepare("
            INSERT INTO avarias
            (ticket_id, utilizador, sala, equipamento, descricao)
            VALUES (?, ?, ?, ?, ?)
        ");

        $ins->execute([
            $t['id'],
            $t['utilizador'],
            $t['sala'],
            $t['equipamento'],
            $t['descricao']
        ]);

        // arquivar ticket
        $pdo->prepare("
            UPDATE tickets
            SET estado = 'valido'
            WHERE id = ?
       ")->execute([$id]);
    }
}

// -----------------------------
// BUSCAR TICKETS
// -----------------------------
$stmt = $pdo->query("
    SELECT *
    FROM tickets
    WHERE estado = 'pendente'
    ORDER BY id DESC
");

$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt">

<head>
<meta charset="UTF-8">
<title>Gerir Tickets</title>
</head>

<br>

<a href="dashboard.php">
    <button type="button">
        Voltar ao Dashboard
    </button>
</a>

<body>

<h1>Gerir Tickets</h1>

<?php if (count($tickets) === 0): ?>

    <p>Não existem tickets.</p>

<?php else: ?>

    <table class="tabela">

        <tr>
            <th>ID</th>
            <th>Utilizador</th>
            <th>Sala</th>
            <th>Equipamento</th>
            <th>Descrição</th>
            <th>Ação</th>
        </tr>

        <?php foreach ($tickets as $ticket): ?>

        <tr>

            <td><?= $ticket['id'] ?></td>

            <td><?= htmlspecialchars($ticket['utilizador']) ?></td>

            <td><?= htmlspecialchars($ticket['sala']) ?></td>

            <td><?= htmlspecialchars($ticket['equipamento']) ?></td>

            <td><?= htmlspecialchars($ticket['descricao']) ?></td>

            <td>
                <a href="?validar=<?= $ticket['id'] ?>">
                    Validar
                </a>
            </td>

        </tr>

        <?php endforeach; ?>

    </table>

<?php endif; ?>

</body>
</html>
