<?php
    session_start();
    require_once "ligabd.php"; //ligação à bd
    //header("Content-Type: text/plain; charset=UTF-8");

    // -----------------------------
    // VALIDAÇÃO DE CRITÉRIOS DE SEGURANÇA DA PASSWORD
    // -----------------------------
    function validarPassword(string $password): bool {
        if (strlen($password) < 10) { //10 CARATERES
           return false;
        }

        $hasUpper = false; //letra maiúscula
        $hasLower = false; //letra minuscula
        $hasDigit = false; //números
        $hasSymbol = false; //símbolos

        for ($i = 0; $i < strlen($password); $i++) {
            $c = $password[$i];

            if (ctype_upper($c)) {
                $hasUpper = true;
            }
            elseif (ctype_lower($c)) {
                $hasLower = true;
            }
            elseif (ctype_digit($c)) {
                $hasDigit = true;
            }
            elseif ($c == '-' || $c == '.' || $c == '!' || $c == '?' ) { //símbolos permitidos
                $hasSymbol = true;
            }
            else {
                return false;
            }
        }
        return $hasUpper && $hasLower && $hasDigit && $hasSymbol;
    }

    // -----------------------------
    // VERIFICAR SE UTILIZADOR EXISTE
    // -----------------------------
    function userExiste(PDO $pdo, string $username): bool {
        $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE username = ?");
        $stmt->execute([$username]);
        return $stmt->fetchColumn() !== false;
    }

    // -----------------------------
    // CRIAR UTILIZADOR
    // -----------------------------
    function criarUser(PDO $pdo, string $username, string $password): bool {
        $hash = password_hash($password, PASSWORD_BCRYPT); // Encripta a password
        $stmt = $pdo->prepare("INSERT INTO utilizadores (username, password_hash, tipo) VALUES (?, ?, 'user')");
    return $stmt->execute([$username, $hash]);
    }

    // -----------------------------
    // VALIDAR LOGIN
    // -----------------------------
    function validarLogin(PDO $pdo, string $username, string $password): string|false {
        $stmt = $pdo->prepare("SELECT password_hash, tipo FROM utilizadores WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password_hash'])) {
        return $user['tipo']; // Devolve 'admin' ou 'user'
    }
    return false;
    }

    // -----------------------------
    // PROCESSAMENTO PRINCIPAL
    // -----------------------------
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $acao = $_POST['acao'] ?? '';

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm'] ?? '';

        // -------------------------
        // CRIAR CONTA
        // -------------------------
        if ($acao === "criar") {
            if (empty($username) || empty($password)) {
                echo "Campos obrigatórios em falta.";
                exit;
            }

            if (userExiste($pdo, $username)) {
                echo "Utilizador já existe.";
                exit;
            }

            if (!validarPassword($password)) {
                echo "Password inválida.";
                exit;
            }

            if ($password !== $confirm) {
                echo "Passwords não coincidem.";
                exit;
            }

            if (criarUser($pdo, $username, $password)) {
                header("Location: index.html");
            } else {
                echo "Erro ao criar conta.";
            }
        }

        // -------------------------
        // LOGIN
        // -------------------------
        if ($acao === "login") {
            $resultado = validarLogin($pdo, $username, $password);
            
                if ($resultado) {
                    $_SESSION['utilizador_id'] = $username; // Alterado de usuario_id
                    $_SESSION['utilizador_tipo'] = $resultado; // Alterado de usuario_tipo
                    $_SESSION['logado'] = true;
                    
                    // Redireccionamento condicional baseado no tipo de utilizador
                    if ($resultado === 'admin') {
                        header("Location: dashboard.php");
                    } else {
                        header("Location: inconformidades.php");
                    }
        
                    exit;
                } else {
                    echo "Credenciais inválidas.";
                }
            
        }
    }
