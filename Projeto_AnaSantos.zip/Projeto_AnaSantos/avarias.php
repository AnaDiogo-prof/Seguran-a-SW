<?php
session_start();
require_once "ligabd.php";

// Verificação de segurança
if (!isset($_SESSION['logado'])) {
    header("Location: index.php");
    exit;
}

$mensagem = "";
$sucesso = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $utilizador = $_SESSION['utilizador_id'];
    $sala = $_POST['sala'] ?? '';
    $equipamento = $_POST['equipamento'] ?? '';
    $descricao = trim($_POST['descricao'] ?? '');

    // Validação
    if (!preg_match('/^[a-zA-Z0-9áéíóúàèìòùâêîôûãõçÁÉÍÓÚÀÈÌÒÙÂÊÎÔÛÃÕÇ\s.,;-]*$/u', $descricao)) {
        die("Erro: A descrição contém símbolos não permitidos.");
    }

    if (empty($sala) || empty($equipamento) || empty($descricao)) {
        die("Erro: Todos os campos são obrigatórios.");
    }

    try {
        $sql = "INSERT INTO tickets (utilizador, sala, equipamento, descricao) VALUES (?, ?, ?, ?)";

        $stmt = $pdo->prepare($sql);

        if ($stmt->execute([$utilizador, $sala, $equipamento, $descricao])) {

            // Espera 3 segundos antes de redirecionar
            header("Refresh: 3; URL=inconformidades.php");

            $mensagem = "Avaria registada com sucesso!";
            $sucesso = true;

        } else {
            $mensagem = "Erro ao registar a avaria.";
        }

    } catch (PDOException $e) {
        die("Erro na base de dados: " . $e->getMessage());
    }

} else {
    header("Location: inconformidades.php");
    exit;
}
