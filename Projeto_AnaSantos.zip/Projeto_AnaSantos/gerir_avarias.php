<?php
session_start();
require_once "ligabd.php";

// Segurança: Apenas o administrador pode aceder a esta página
if (!isset($_SESSION['logado']) || $_SESSION['utilizador_tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// --- PROCESSAMENTO: Marcar como Resolvido ---
if (isset($_GET['resolver_id'])) {
    $id_da_avaria = $_GET['resolver_id'];
    
    // Atualiza o estado e regista a data/hora atual no campo data_resolucao
    $sql = "UPDATE avarias SET estado = 'resolvido', data_resolucao = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id_da_avaria]);
    
    // Redireciona para o próprio ficheiro para limpar o ID da URL e atualizar a lista
    header("Location: gerir_avarias.php");
    exit;
}

// Procurar todas as avarias validadas (ordenadas pelas mais recentes)
$lista = $pdo->query("SELECT * FROM avarias ORDER BY data_validacao DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Avarias - Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <span>Painel de Resolução de Avarias</span>
        <div class="user-info">
            <span>Admin: <strong><?php echo htmlspecialchars($_SESSION['utilizador_id']); ?></strong></span>
            <a href="logout.php" class="btn-logout">Sair</a>
        </div>
    </header>

    <div class="container" style="max-width: 900px;">
        <h2>Lista de Avarias Validadas</h2>
        
        <?php if (count($lista) > 0): ?>
            <table border="1" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <thead>
                    <tr style="background-color: #4a6fa5; color: white;">
                        <th>Sala</th>
                        <th>Equipamento</th>
                        <th>Descrição</th>
                        <th>Estado</th>
                        <th>Ação / Data Resolução</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lista as $avaria): ?>
                    <tr style="text-align: center;">
                        <td><?php echo htmlspecialchars($avaria['sala']); ?></td>
                        <td><?php echo htmlspecialchars($avaria['equipamento']); ?></td>
                        <td><?php echo htmlspecialchars($avaria['descricao']); ?></td>
                        <td style="font-weight: bold; color: <?php echo ($avaria['estado'] === 'pendente') ? 'orange' : 'green'; ?>;">
                            <?php echo strtoupper($avaria['estado']); ?>
                        </td>
                        <td>
                            <?php if ($avaria['estado'] === 'pendente'): ?>
                                <a href="gerir_avarias.php?resolver_id=<?php echo $avaria['id']; ?>"
                                   onclick="return confirm('Confirmar resolução desta avaria?')"
                                   style="color: blue; text-decoration: underline;">
                                   Marcar como Resolvida
                                </a>
                            <?php else: ?>
                                <span style="font-size: 0.9em; color: #666;">
                                    Resolvida em:<br>
                                    <?php echo date('d/m/Y H:i', strtotime($avaria['data_resolucao'])); ?>
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; margin-top: 20px;">Não existem avarias validadas para gerir.</p>
        <?php endif; ?>

        <div style="margin-top: 30px; text-align: center;">
            <a href="dashboard.php" style="color: #4a6fa5; font-weight: bold;">← Voltar ao Dashboard</a>
        </div>
    </div>

    <footer>
        Desenvolvido por Ana Santos em 2026
    </footer>

</body>
</html>
