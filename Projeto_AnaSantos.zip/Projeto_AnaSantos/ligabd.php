<?php
// -----------------------------
// CONFIGURAÇÃO DA BASE DE DADOS
// -----------------------------
$host = "localhost"; // endereço do servidor da base de dados (local)
$dbname = "userlogin"; // nome da bd
$user = "root"; // utilizador da bd
$pass = ""; // palavra-passe do root

// -----------------------------
// TENTATIVA DE LIGAÇÃO À BASE DE DADOS
// -----------------------------
try {
    // Criar uma nova ligação segura (PDO) à bd
    $pdo = new PDO("mysql:host=$host;charset=utf8", $user, $pass);
    // definir o modo de erro do PDO para lançar exceções para capturar erros de forma mais clara
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Criar a Base de Dados se não existir
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8 COLLATE utf8_general_ci");
    
    // Selecionar a Base de Dados
    $pdo->exec("USE `$dbname` ");

    // Criar a tabela 'utilizadores' se não existir
    $sql = "CREATE TABLE IF NOT EXISTS utilizadores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        tipo ENUM('user', 'admin') DEFAULT 'user',
        data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;";
    $pdo->exec($sql);

    //Criar utilizador administrador pré-definido para testar gestão do website
    $adminUser = 'admin';
    $adminPass = password_hash('123456.Abc', PASSWORD_BCRYPT);
    
    $sqlAdmin = "INSERT IGNORE INTO utilizadores (username, password_hash, tipo)
                 VALUES (:user, :pass, 'admin')";
    
    $stmt = $pdo->prepare($sqlAdmin);
    $stmt->execute(['user' => $adminUser, 'pass' => $adminPass]);

    // Tabela de Tickets
    $pdo->exec("CREATE TABLE IF NOT EXISTS tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        utilizador VARCHAR(50),
        sala VARCHAR(30),
        equipamento VARCHAR(50),
        descricao TEXT,
        data_registo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        estado VARCHAR(20) DEFAULT 'pendente'
    ) ENGINE=InnoDB;");

    // Tabela de Avarias Validadas pelo admin
    $pdo->exec("CREATE TABLE IF NOT EXISTS avarias (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ticket_id INT,
        utilizador VARCHAR(50),
        sala VARCHAR(30),
        equipamento VARCHAR(50),
        descricao TEXT,
        estado ENUM('pendente', 'resolvido') DEFAULT 'pendente',
        data_validacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_resolucao DATETIME NULL,
        FOREIGN KEY (ticket_id) REFERENCES tickets(id)
    ) ENGINE=InnoDB;");
    
} catch (PDOException $e) {
    die("Erro crítico na infraestrutura: " . $e->getMessage());
}
