<?php
session_start();

// Verificação de segurança: só o tipo 'user' acede
if (!isset($_SESSION['logado']) || $_SESSION['utilizador_tipo'] !== 'user') {
    // Se não estiver logado ou não for um utilizador comum, é expulso para o index
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Registo de Avarias</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <span>Registo de Avarias</span>
        <div class="user-info">
            <span>Utilizador: <strong><?php echo htmlspecialchars($_SESSION['utilizador_id']); ?></strong></span>
            <a href="logout.php" class="btn-logout">Sair</a>
        </div>
    </header>

    <div class="container">
        <h2>Reportar Nova Avaria</h2>
        
        <form action="avarias.php" method="POST">
            
            <label for="sala">Sala:</label>
            <select name="sala" id="sala" required>
                <?php
                $salas = [
                    "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16",
                    "Ginásio", "INF1", "INF2", "LabC", "LabI", "LabF", "LabQ", "LabB",
                    "Artes", "unidade", "PBX", "Reprografia", "Bar", "Portaria", "Cozinha"
                ];
                foreach ($salas as $s) {
                    echo "<option value=\"$s\">$s</option>";
                }
                ?>
            </select>

            <label for="equipamento">Equipamento:</label>
            <select name="equipamento" id="equipamento" required>
                <option value="Computador">Computador</option>
                <option value="Projetor de Vídeo">Projetor de Vídeo</option>
                <option value="Internet">Internet</option>
                <option value="cabos">cabos</option>
            </select>

            <label for="descricao">Descrição da Avaria:</label>
            <textarea
                name="descricao"
                id="descricao"
                rows="4"
                required
                placeholder="Descreva o problema aqui..."
                style="width: 100%; border-radius: 5px; border: 1px solid #ccc; padding: 10px;"
                pattern="^[a-zA-Z0-9\s.,;-]*$"
                title="Apenas são permitidos os símbolos: . , ; -"></textarea>

            <button type="submit" style="margin-top: 15px;">Enviar Registo</button>
        </form>
    </div>

    <footer>
        Desenvolvido por Ana Santos em 2026
    </footer>

</body>
</html>
