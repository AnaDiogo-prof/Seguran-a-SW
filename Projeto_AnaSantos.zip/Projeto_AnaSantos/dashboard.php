<?php
session_start();
require_once "ligabd.php";

// Verificação de segurança: Só o tipo 'admin' acede
if (!isset($_SESSION['logado']) || $_SESSION['utilizador_tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Administração</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <span>Painel de Controlo (Admin)</span>
        <div class="user-info">
            <span>Utilizador: <strong><?php echo htmlspecialchars($_SESSION['utilizador_id']); ?></strong></span>
            <a href="logout.php" class="btn-logout">Sair</a>
        </div>
    </header>

    <div class="container">
        <h2>Gestão de Sistema</h2>
        <ul>
            <li><a href="gerir_tickets.php">Validar Tickets</a></li>
            <li><a href="gerir_avarias.php">Gerir Avarias</a></li>
            <li><a href="gerir_utilizadores.php">Gerir Utilizadores</a></li>
        </ul>
    </div>

    <footer>
        Desenvolvido por Ana Santos em 2026
    </footer>

</body>
</html>
